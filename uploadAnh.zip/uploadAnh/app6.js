const express = require('express');
const path = require('path');
const fs = require('fs');
const multer  = require('multer');

const app = express();
const upload = multer({ dest: 'uploads/' });

// Cấu hình phục vụ các tệp từ thư mục "uploads" tại URL "/uploads"
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Cấu hình đường dẫn tới template engine (ví dụ: EJS)
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Route để render trang hiển thị ảnh và xử lý upload ảnh
app.get('/gallery', (req, res) => {
    // Đọc tất cả các tệp trong thư mục "uploads"
    fs.readdir(path.join(__dirname, 'uploads'), (err, files) => {
        if (err) {
            console.error('Error reading uploads directory:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        // Render trang gallery và truyền danh sách tệp ảnh vào template
        res.render('gallery', { images: files });
    });
});

// Route để xử lý upload ảnh
app.post('/upload', upload.single('image'), (req, res) => {
    res.redirect('/gallery');
});

app.listen(3001, () => {
    console.log('Server is running on port 3001');
});
