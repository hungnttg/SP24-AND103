package com.hungnq123.myapplication12.retrofit1;

public class SvrResponseProd {//GET
    private Prod[] products;
    private String message;

    public Prod[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
