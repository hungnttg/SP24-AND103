package com.hungnq123.myapplication12.retrofit1;

public class SvrResponsePrd {//GET
    private Prd products;
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
